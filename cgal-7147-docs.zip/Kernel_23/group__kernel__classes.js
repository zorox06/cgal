var group__kernel__classes =
[
    [ "CGAL::Cartesian&lt; FieldNumberType &gt;", "struct_c_g_a_l_1_1_cartesian.html", [
      [ "FT", "struct_c_g_a_l_1_1_cartesian.html#a8cb4bfb5620f0972f846f002db57f67e", null ],
      [ "RT", "struct_c_g_a_l_1_1_cartesian.html#a4669cacde64b5fe6f7a35f4844c58398", null ]
    ] ],
    [ "CGAL::Filtered_kernel_adaptor&lt; CK &gt;", "struct_c_g_a_l_1_1_filtered__kernel__adaptor.html", null ],
    [ "CGAL::Filtered_kernel&lt; CK, UseStaticFilters &gt;", "struct_c_g_a_l_1_1_filtered__kernel.html", [
      [ "Approximate_kernel", "struct_c_g_a_l_1_1_filtered__kernel.html#ae72cbb94616fe734950bcbf8b087bfba", null ],
      [ "Exact_kernel", "struct_c_g_a_l_1_1_filtered__kernel.html#a30aad0394da1283eb3d2ac87f0aa36df", null ],
      [ "Has_static_filters", "struct_c_g_a_l_1_1_filtered__kernel.html#a0203e552b521b48dd3e511e5af124a7b", null ]
    ] ],
    [ "CGAL::Filtered_predicate&lt; EP, FP, C2E, C2F &gt;", "class_c_g_a_l_1_1_filtered__predicate.html", [
      [ "result_type", "class_c_g_a_l_1_1_filtered__predicate.html#a00994ff1203ba65f07f287fdad8a84d0", null ],
      [ "Filtered_predicate", "class_c_g_a_l_1_1_filtered__predicate.html#aceeaaa1be5fc314c422d527f69fca2b0", null ],
      [ "operator()", "class_c_g_a_l_1_1_filtered__predicate.html#a6c997ac1bdef0a6e2b4428aa4fdc9d00", null ]
    ] ],
    [ "CGAL::Homogeneous&lt; RingNumberType &gt;", "struct_c_g_a_l_1_1_homogeneous.html", [
      [ "FT", "struct_c_g_a_l_1_1_homogeneous.html#a002a92b6c4048842b3bf528f3c4bacf7", null ],
      [ "RT", "struct_c_g_a_l_1_1_homogeneous.html#a79110268c6cc705967095874abe53e6d", null ]
    ] ],
    [ "CGAL::Kernel_traits&lt; T &gt;", "struct_c_g_a_l_1_1_kernel__traits.html", [
      [ "Kernel", "struct_c_g_a_l_1_1_kernel__traits.html#adaf2b06e17d5377307fca20b6bc2bbf9", null ]
    ] ],
    [ "CGAL::Projection_traits_3&lt; GeomTraits &gt;", "class_c_g_a_l_1_1_projection__traits__3.html", [
      [ "Projection_traits_3", "class_c_g_a_l_1_1_projection__traits__3.html#ae31ea8acd955b3c5041e29d1748e374e", null ]
    ] ],
    [ "CGAL::Projection_traits_xy_3&lt; Gt &gt;", "class_c_g_a_l_1_1_projection__traits__xy__3.html", [
      [ "Intersect_2", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a546d8c7b6f978b535af0e384171e65f0", null ],
      [ "Line_2", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a970383921efae9936fe714faa573846a", null ],
      [ "Point_2", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a498ff8ec4d937ea7ecde0751c61fbbbb", null ],
      [ "Segment_2", "class_c_g_a_l_1_1_projection__traits__xy__3.html#aff036abecc7f61be9b275cd619844c17", null ],
      [ "Triangle_2", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a3c208acd0c97735e80345fb3f29a71a3", null ],
      [ "Projection_traits_xy_3", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a68d8c26d1ca2c72911029a26b2486f2c", null ],
      [ "Projection_traits_xy_3", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a640b04a1cab2024cb750f98807ea83d8", null ],
      [ "operator=", "class_c_g_a_l_1_1_projection__traits__xy__3.html#a93ce42f171802a5959965c1d30bc3422", null ]
    ] ],
    [ "CGAL::Projection_traits_xz_3&lt; Gt &gt;", "class_c_g_a_l_1_1_projection__traits__xz__3.html", null ],
    [ "CGAL::Projection_traits_yz_3&lt; Gt &gt;", "class_c_g_a_l_1_1_projection__traits__yz__3.html", null ],
    [ "CGAL::Simple_cartesian&lt; FieldNumberType &gt;", "struct_c_g_a_l_1_1_simple__cartesian.html", [
      [ "FT", "struct_c_g_a_l_1_1_simple__cartesian.html#a7c21b43a7da612194bd57c927f80ebc3", null ],
      [ "RT", "struct_c_g_a_l_1_1_simple__cartesian.html#a33d4df5a291b37d25476b6f35c1d1bf9", null ]
    ] ],
    [ "CGAL::Simple_homogeneous&lt; RingNumberType &gt;", "struct_c_g_a_l_1_1_simple__homogeneous.html", [
      [ "FT", "struct_c_g_a_l_1_1_simple__homogeneous.html#a3437428a4684ec9298cbf3b63f2fa560", null ],
      [ "RT", "struct_c_g_a_l_1_1_simple__homogeneous.html#a7cd6934f5eef128a6368f9ec3bfee0ba", null ]
    ] ]
];