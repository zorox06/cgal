/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "CGAL 6.3-dev - 2D and 3D Linear Geometry Kernel", "index.html", [
    [ "User Manual", "index.html", "index" ],
    [ "Reference Manual", "topics.html", "topics" ],
    [ "Todo List", "todo.html", null ],
    [ "Bibliography", "citelist.html", null ],
    [ "Class and Concept List", "annotated.html", "annotated" ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_filtered_kernel_2_filtered_predicate_8cpp-example.html",
"class_c_g_a_l_1_1_iso__rectangle__2.html#ad6b5b429c4c1ad62cc5bdb34207f5683",
"class_c_g_a_l_1_1_sphere__3.html#a3b87bca471e46cff11858474a7a97999",
"class_kernel.html#a329daefa3f2da19469ea43b361383c4c",
"class_kernel_1_1_angle__2.html#a45f9ca06ad3b86d72d27dd909008e8de",
"class_kernel_1_1_compute_squared_radius_smallest_orthogonal_sphere__3.html",
"class_kernel_1_1_construct_point__3.html",
"class_kernel_1_1_is_degenerate__2.html#a38e979d82f2deeb51af6b43caad803a2",
"group__compare__x__spherical__grp.html#ga8e7a74c1584c377bc410425b01da2970",
"group__x__equal__grp.html#gab4f8fb5007b5a620bfb127f2ba322bf5"
];

const SYNCONMSG = 'click to disable panel synchronization';
const SYNCOFFMSG = 'click to enable panel synchronization';
const LISTOFALLMEMBERS = 'List of all members';