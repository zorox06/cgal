var searchData=
[
  ['argument_5ftype_0',['argument_type',['../class_adaptable_unary_function.html#a68c8164d96fc5a826edce4924d7b3f21',1,'AdaptableUnaryFunction']]]
];
