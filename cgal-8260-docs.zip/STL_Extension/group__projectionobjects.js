var group__projectionobjects =
[
    [ "CGAL::Cast_function_object&lt; Arg, Result &gt;", "struct_c_g_a_l_1_1_cast__function__object.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_cast__function__object.html#a8a4e35876a1995877eb195e92278229e", null ],
      [ "result_type", "struct_c_g_a_l_1_1_cast__function__object.html#a723317152de954abf8cff384abda3bc6", null ],
      [ "Cast_function_object", "struct_c_g_a_l_1_1_cast__function__object.html#aea2cf2ca9e610e52504ebf10681619ce", null ],
      [ "operator()", "struct_c_g_a_l_1_1_cast__function__object.html#ac8c00c2271fd86d53614dec3e03fecaf", null ],
      [ "operator()", "struct_c_g_a_l_1_1_cast__function__object.html#ac9fd4bfbc1998ed13d6957d26c3f547e", null ]
    ] ],
    [ "CGAL::Compare_to_less&lt; F &gt;", "class_c_g_a_l_1_1_compare__to__less.html", [
      [ "Type", "class_c_g_a_l_1_1_compare__to__less.html#aabca75dea18a68e29ccc5de553a8ca75", null ]
    ] ],
    [ "CGAL::Dereference&lt; Value &gt;", "struct_c_g_a_l_1_1_dereference.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_dereference.html#aa1e2e6b14dc7c16a3e5ea7bbf1d9ab8c", null ],
      [ "result_type", "struct_c_g_a_l_1_1_dereference.html#a989469a6445a343423c7b469bff9f202", null ],
      [ "Dereference", "struct_c_g_a_l_1_1_dereference.html#a45d10c6f1595754f1bb10e26a0a86539", null ],
      [ "operator()", "struct_c_g_a_l_1_1_dereference.html#a8ab5bb33b75d9d2ad189c35701c7e2a7", null ],
      [ "operator()", "struct_c_g_a_l_1_1_dereference.html#ae7b468f45ac474396a1ed85f73c38b36", null ]
    ] ],
    [ "CGAL::Get_address&lt; Value &gt;", "struct_c_g_a_l_1_1_get__address.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_get__address.html#a0fa3b36c97cf27e85386597a8ecd9077", null ],
      [ "result_type", "struct_c_g_a_l_1_1_get__address.html#acff82fdd103f7af8c416e98576512012", null ],
      [ "Get_address", "struct_c_g_a_l_1_1_get__address.html#aa451ba00841e8b7bb7b01a27b6842a83", null ],
      [ "operator()", "struct_c_g_a_l_1_1_get__address.html#acb4ded5e9e9c8615a37671d4ade84f44", null ],
      [ "operator()", "struct_c_g_a_l_1_1_get__address.html#a3fd8d9a6e7042769087b00b6e25cf093", null ]
    ] ],
    [ "CGAL::Identity&lt; Value &gt;", "struct_c_g_a_l_1_1_identity.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_identity.html#afe53c003bbd6f0f378a3e2d4d3ffbe10", null ],
      [ "result_type", "struct_c_g_a_l_1_1_identity.html#a62b06f74a12c7bf372a63397496053f1", null ],
      [ "Identity", "struct_c_g_a_l_1_1_identity.html#ac2ba7daed18befaa7ac51b028813e588", null ],
      [ "operator()", "struct_c_g_a_l_1_1_identity.html#ac3ef36404d3e7df688d742c259fccc2c", null ],
      [ "operator()", "struct_c_g_a_l_1_1_identity.html#ab7d5a2ea9abb7fe5285527106ed752a0", null ]
    ] ],
    [ "CGAL::Project_facet&lt; Node &gt;", "struct_c_g_a_l_1_1_project__facet.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__facet.html#adb022e8b885739d64d89861074f56fd8", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__facet.html#a0db4b3ef346158ef86a14b738f3228b5", null ],
      [ "Project_facet", "struct_c_g_a_l_1_1_project__facet.html#a3672babf3fb29c348c99b07a009215a2", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__facet.html#a51e979a39cac5c9efa2550fd6c522b62", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__facet.html#a7d68712530fc7176813a5f6bb7b9aed0", null ]
    ] ],
    [ "CGAL::Project_next&lt; Node &gt;", "struct_c_g_a_l_1_1_project__next.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__next.html#adfccb57fe6e067ad4897b681dd9c3478", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__next.html#aa8d54b72df1339a589c2dfec387e07f5", null ],
      [ "Project_next", "struct_c_g_a_l_1_1_project__next.html#aa26465dfb1c9e64a6a24fcb8179ee78a", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__next.html#a4f1191bb387681eae7e4f38beae023be", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__next.html#aa86dc045ed7fcf31f50b84a99e03f26a", null ]
    ] ],
    [ "CGAL::Project_next_opposite&lt; Node &gt;", "struct_c_g_a_l_1_1_project__next__opposite.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__next__opposite.html#a0b39526416967862eb6711cbd36d66df", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__next__opposite.html#a8fe7688cd6f51cf246edd877081f7218", null ],
      [ "Project_next_opposite", "struct_c_g_a_l_1_1_project__next__opposite.html#ae6cad15d2d24cb66e2bf0592873ee562", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__next__opposite.html#aa1f6c363725cae16515ac50fb14cd6e1", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__next__opposite.html#ace7a9b1ac193ef04af875acd06ceb69d", null ]
    ] ],
    [ "CGAL::Project_normal&lt; Node &gt;", "struct_c_g_a_l_1_1_project__normal.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__normal.html#afaa3c7e7fac13bc85bbe5e04e67a9d8f", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__normal.html#a36f07790a367dda5a231467dc5cd7a36", null ],
      [ "Project_normal", "struct_c_g_a_l_1_1_project__normal.html#a23e5f021fb827534384148527aff1261", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__normal.html#a4bcb2e7fe9ecf2b32291ec7df804f13b", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__normal.html#a3fcca537afd13626b4521f401c4e611b", null ]
    ] ],
    [ "CGAL::Project_opposite_prev&lt; Node &gt;", "struct_c_g_a_l_1_1_project__opposite__prev.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__opposite__prev.html#ad69e2ddf528d51853278e4a592ce0423", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__opposite__prev.html#a160400454e8b00e8f2d02fc8a921dbd0", null ],
      [ "Project_opposite_prev", "struct_c_g_a_l_1_1_project__opposite__prev.html#a8cb71c6f910a336826beac35fbd07d6e", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__opposite__prev.html#a7fec8d04a0d364b6b1f3429090e060d1", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__opposite__prev.html#af9a0b2db77279500231b010a0a53b4cf", null ]
    ] ],
    [ "CGAL::Project_plane&lt; Node &gt;", "struct_c_g_a_l_1_1_project__plane.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__plane.html#a812bca258e8b8a5eb349ca5e05b01c96", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__plane.html#a935f953e46e31a2fa258710d9f020c67", null ],
      [ "Project_plane", "struct_c_g_a_l_1_1_project__plane.html#a299a0ec810a7c050551b985a3655eb83", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__plane.html#a2482130886c15c3ed915857fb169a8f2", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__plane.html#ae24758b5b396804d805e1d5552c692b1", null ]
    ] ],
    [ "CGAL::Project_point&lt; Node &gt;", "struct_c_g_a_l_1_1_project__point.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__point.html#a513f0671f76319832a13abc1037dbb28", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__point.html#a47db02b00230f99a68fc486cb9bdcf50", null ],
      [ "Project_point", "struct_c_g_a_l_1_1_project__point.html#a93808426a268e43a52a90d65f0df4d00", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__point.html#a3b34ce88feeaf23af4a478514bc4a271", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__point.html#ae420ffb882755d4a28fcf867f6778512", null ]
    ] ],
    [ "CGAL::Project_prev&lt; Node &gt;", "struct_c_g_a_l_1_1_project__prev.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__prev.html#a096d6fb65aa613bdfeb9f4c186499ea6", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__prev.html#a5efc72d16ab7c37eeb98ffc8a6aa40d0", null ],
      [ "Project_prev", "struct_c_g_a_l_1_1_project__prev.html#a3054d4fb11768fba4e1734aaf3b169e5", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__prev.html#adbee0f9824a876577e63023f739f703b", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__prev.html#aeafef1c742c9245bf03ac1fe8956b0b4", null ]
    ] ],
    [ "CGAL::Project_vertex&lt; Node &gt;", "struct_c_g_a_l_1_1_project__vertex.html", [
      [ "argument_type", "struct_c_g_a_l_1_1_project__vertex.html#ab6adbb995cf06599a599a5d57f01918a", null ],
      [ "result_type", "struct_c_g_a_l_1_1_project__vertex.html#ac2f56e086e6b48c3b5da9045978a504d", null ],
      [ "Project_vertex", "struct_c_g_a_l_1_1_project__vertex.html#a96b39757c2e7579cd463c0f8322d4351", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__vertex.html#a99cabc28e1e29df73313da15cb4604f6", null ],
      [ "operator()", "struct_c_g_a_l_1_1_project__vertex.html#ad197839e42e2f7d85dcd615f5a254e44", null ]
    ] ],
    [ "CGAL::compare_to_less", "group__projectionobjects.html#gaa343b4e41668290985efff5def93ca7c", null ]
];