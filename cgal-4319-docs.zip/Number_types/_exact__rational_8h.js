var _exact__rational_8h =
[
    [ "CGAL::Exact_rational", "group__nt__cgal.html#ga0849ff44771b19582218ebdfa5614f64", null ]
];