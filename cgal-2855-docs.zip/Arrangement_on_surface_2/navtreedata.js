/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "CGAL 6.3-dev - 2D Arrangements", "index.html", [
    [ "User Manual", "index.html", "index" ],
    [ "Reference Manual", "topics.html", "topics" ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Bibliography", "citelist.html", null ],
    [ "Class and Concept List", "annotated.html", "annotated" ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_arrangement_on_surface_2_2_bezier_curves_8cpp-example.html",
"class_aos_dcel_inner_ccb.html#a714e9ff09d3389c80886bac28500113d",
"class_aos_traits_1_1_construct_x_monotone_curve__2.html",
"class_c_g_a_l_1_1_arr__algebraic__segment__traits__2_1_1_x__monotone__curve__2.html#a56e40dab05f77f153abdf9c8db38c378",
"class_c_g_a_l_1_1_arr__curve__data__traits__2_1_1_x__monotone__curve__2.html#a02773e42fd5d2545837f7230d6219650",
"class_c_g_a_l_1_1_arr__rational__function__traits__2_1_1_construct__curve__2.html#a2fee12818fe865f3bccf1468fcdfaf47",
"class_c_g_a_l_1_1_arrangement__2.html#a4f034d310002a73e70761392024d0d97",
"class_overlay_traits.html#affeba6407709a51771b9b66de1551e94"
];

const SYNCONMSG = 'click to disable panel synchronization';
const SYNCOFFMSG = 'click to enable panel synchronization';
const LISTOFALLMEMBERS = 'List of all members';