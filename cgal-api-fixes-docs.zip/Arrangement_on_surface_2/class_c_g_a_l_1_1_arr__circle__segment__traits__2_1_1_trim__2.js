var class_c_g_a_l_1_1_arr__circle__segment__traits__2_1_1_trim__2 =
[
    [ "operator()", "class_c_g_a_l_1_1_arr__circle__segment__traits__2_1_1_trim__2.html#a4c75f0003a78fed2537f23fb06e4467c", null ]
];