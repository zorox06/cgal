var class_aos_traits_1_1_approximate_point__2 =
[
    [ "Approximate_number_type", "class_aos_traits_1_1_approximate_point__2.html#aaffa34ebd7491f1fede56e9c3cb76aed", null ],
    [ "operator()", "class_aos_traits_1_1_approximate_point__2.html#a0792f16c75752f945c75687cd005c086", null ]
];