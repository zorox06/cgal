var class_aos_approximate_point_traits__2 =
[
    [ "Approximate_2", "class_aos_approximate_point_traits__2.html#a1f023cf1b8aef44162a574f14ac1f08d", null ],
    [ "approximate_2_object", "class_aos_approximate_point_traits__2.html#a9949ec588eb0256ee56076b85a40ebe6", null ]
];