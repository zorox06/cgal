var class_c_g_a_l_1_1_arr__polycurve__traits__2_1_1_trim__2 =
[
    [ "operator()", "class_c_g_a_l_1_1_arr__polycurve__traits__2_1_1_trim__2.html#af4b7494991dc61f67b39947b07fb42f0", null ]
];