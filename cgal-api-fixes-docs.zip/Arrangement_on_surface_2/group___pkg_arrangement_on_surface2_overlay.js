var group___pkg_arrangement_on_surface2_overlay =
[
    [ "CGAL::Arr_default_overlay_traits&lt; Arrangement &gt;", "class_c_g_a_l_1_1_arr__default__overlay__traits.html", null ],
    [ "CGAL::Arr_face_overlay_traits&lt; Arr_A, Arr_B, Arr_R, OvlFaceData &gt;", "class_c_g_a_l_1_1_arr__face__overlay__traits.html", null ]
];