var class_aos_approximate_traits__2 =
[
    [ "Approximate_2", "class_aos_approximate_traits__2.html#adeaafcb52fbca57990ce28f1e16c1dae", null ],
    [ "approximate_2_object", "class_aos_approximate_traits__2.html#a3a710ccb99e56d4663aa53848ee10e89", null ]
];