var group___pkg_triangulations_traits_classes =
[
    [ "CGAL::Regular_triangulation_traits_adapter&lt; RTTraits &gt;", "class_c_g_a_l_1_1_regular__triangulation__traits__adapter.html", [
      [ "Base", "class_c_g_a_l_1_1_regular__triangulation__traits__adapter.html#a3d5508a607861655be35680a4cda46ce", null ],
      [ "Point_d", "class_c_g_a_l_1_1_regular__triangulation__traits__adapter.html#afc18cbe402862aa6184762f052a5e62b", null ],
      [ "Regular_triangulation_traits_adapter", "class_c_g_a_l_1_1_regular__triangulation__traits__adapter.html#aa8c1596d4f159bdad61bc15040c55a61", null ]
    ] ]
];