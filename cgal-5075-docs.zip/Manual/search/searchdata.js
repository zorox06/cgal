var indexSectionsWithContent =
{
  0: "1236abcdefghiklmnopqrstuvwyz",
  1: "abcdefilmoprsuvw",
  2: "c",
  3: "bo",
  4: "afrst",
  5: "1236abcdefghiklmnopqrstuvwyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Typedefs",
  5: "Pages"
};

