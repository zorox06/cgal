var searchData=
[
  ['cgal_0',['CGAL',['../namespace_c_g_a_l.html',1,'']]]
];
